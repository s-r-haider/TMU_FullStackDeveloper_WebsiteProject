Lab 2 is an exercise in creating and using a Git repository.
