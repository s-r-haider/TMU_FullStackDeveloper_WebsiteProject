from flask import Flask, jsonify, request, render_template

#from flask_mongoengine import MongoEngine
from mongoengine import *

app = Flask(__name__)

"""
# MongoDB connection setup
app.config['MONGODB_SETTINGS'] = { 'db':'CKCS145', 'host':'localhost', 'port':27017 }
db = MongoEngine()
db.init_app(app)
"""

#client = connect('CKCS145', username='username', password='password', authentication_source='admin')
client = connect('CKCS145', username='', password='')



# Data Class for accessing MongoDB collection
class Customer(Document) :
  #id = IntField()
  name = StringField()
  quantity = IntField()
  price = IntField()
  meta = { 'collection' : 'Customer', 'allow_inheritance': False }

# http://localhost:5000/customer/list
@app.route('/customer/list', methods = ['GET']) #Enable GET and POST
def list_customers():	
    
  data = list(Customer.objects)  # Create a list
  
  print( Customer.objects.to_json() )
  print( data )
  
  json_val = Customer.objects.to_json() 
  
  #return data
  #return 'success'  
  #return json_val
  
  return jsonify( Customer.objects.to_json() ) 
  #return json.loads( Customer.objects.to_json() ) 
  
  
  
  
if __name__ == '__main__':
  app.run(debug=True)
