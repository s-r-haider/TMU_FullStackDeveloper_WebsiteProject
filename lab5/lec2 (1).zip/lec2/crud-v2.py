from flask import Flask, jsonify, request, render_template
import mongoengine as db
import json


# Flask application object
app = Flask(__name__)

# MongoDB connection setup
client = db.connect('CKCS145', username='', password='')


# Data Class for accessing MongoDB collection
class Customer(db.Document) :
  #id = db.IntField()
  name = db.StringField()
  quantity = db.IntField()
  price = db.IntField()
  meta = { 'collection' : 'Customer', 'allow_inheritance': False }


# http://localhost:5000/customer/list
@app.route('/customer/list', methods = ['GET']) #Enable GET and POST
def list_customers():	

  # Used for debug to print to terminal.
  for customer in Customer.objects :
    print(customer)    # prints objec type, not its values
    print(customer.name, customer.quantity, customer.price)  # print values of object
    print()  
    
  return json.loads( Customer.objects.to_json() )
  

# http://localhost:5000/customer/insert
@app.route('/customer/insert', methods = ['POST'] )  
def insert_customers() :	
  customer_name_val = request.form.get('CustomerName')
  quantity_val = request.form.get('Quantity')
  price_val = request.form.get('Price')
  
  # DEBUG
  print( 'Debug values: ', customer_name_val, quantity_val, price_val)
  
  newCustomer = Customer( name = customer_name_val, quantity = quantity_val, price = price_val)
  newCustomer.save()
  
  return 'success'

# http://localhost:5000/ui/customer/insert
@app.route('/ui/customer/insert', methods = ['GET', 'POST'] )  
def insert_customers_ui() :	
  if(request.method == 'GET'):
    return render_template('insertform.html')
    
  customer_name_val = request.form.get('CustomerName')
  quantity_val = request.form.get('Quantity')
  price_val = request.form.get('Price')
  
  # DEBUG
  print( 'Debug values: ', customer_name_val, quantity_val, price_val)
  
  newCustomer = Customer( name = customer_name_val, quantity = quantity_val, price = price_val)
  newCustomer.save()
  
  return 'success'
  

# http://localhost:5000/customer/delete
# Note: try deleting the same name two or three times and notice "no customer has been found, nothing to delete" message.
@app.route('/customer/delete', methods=['POST'] )
def delete_customer() :

  message = 'success'
  
  customer_name_val = request.form.get('CustomerName')  
  customers = Customer.objects( name = customer_name_val )

  customer = customers.first()
  if not customer :
    print('no customer has been found, nothing to delete')
    message = 'nothing to delete'
  else :
    customer.delete()
  
  return message


# http://localhost:5000/ui/customer/delete
# Note: try deleting the same name two or three times and notice "no customer has been found, nothing to delete" message.
@app.route('/ui/customer/delete', methods=['GET', 'POST'] )
def delete_customer_ui() :

  if(request.method == 'GET'):
    return render_template('deleteform.html')

  message = 'success'
  
  customer_name_val = request.form.get('CustomerName')  
  customers = Customer.objects( name = customer_name_val )

  customer = customers.first()
  if not customer :
    print('no customer has been found, nothing to delete')
    message = 'nothing to delete'
  else :
    customer.delete()
  
  return message


# http://localhost:5000/customer/update
@app.route('/customer/update', methods=['POST'] )
def update_customer() :

  message = 'success'
  
  customer_name_val = request.form.get('CustomerName')  # keep the customer name the same
  new_customer_name_val = request.form.get('NewCustomerName')  # update this field
  new_quantity_val = request.form.get('NewQuantity')  # update this field
  new_price_val = request.form.get('NewPrice')  # update this field
  
  customers = Customer.objects( name = customer_name_val )

  customer = customers.first()
  if not customer :
    print('no customer has been found, nothing to update')
    message = 'nothing to update since customer does not exist'
  else :
    #customer.delete()
    customer.name = new_customer_name_val
    customer.quantity = int( new_quantity_val )
    customer.price = int( new_price_val )
    customer.save()
    
  return message


# http://localhost:5000/ui/customer/update
@app.route('/ui/customer/update', methods=['GET', 'POST'] )
def update_customer_ui() :

  if(request.method == 'GET'):
    return render_template('updateform.html')
    
  message = 'success'
  
  customer_name_val = request.form.get('CustomerName')  # keep the customer name the same
  new_customer_name_val = request.form.get('NewCustomerName')  # update this field
  new_quantity_val = request.form.get('NewQuantity')  # update this field
  new_price_val = request.form.get('NewPrice')  # update this field
  
  customers = Customer.objects( name = customer_name_val )

  customer = customers.first()
  if not customer :
    print('no customer has been found, nothing to update')
    message = 'nothing to update since customer does not exist'
  else :
    #customer.delete()
    customer.name = new_customer_name_val
    customer.quantity = int( new_quantity_val )
    customer.price = int( new_price_val )
    customer.save()
    
  return message


if __name__ == '__main__':
  app.run(debug=True)


